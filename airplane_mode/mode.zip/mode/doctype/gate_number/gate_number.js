// Copyright (c) 2024, yugandhara and contributors
// For license information, please see license.txt

// frappe.ui.form.on("Gate Number", {
// 	refresh(frm) {

// 	},
// });
