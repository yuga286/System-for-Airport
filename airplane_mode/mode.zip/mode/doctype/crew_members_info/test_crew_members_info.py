# Copyright (c) 2024, yugandhara and Contributors
# See license.txt

# import frappe
from frappe.tests.utils import FrappeTestCase


class TestCrewMembersInfo(FrappeTestCase):
	pass
